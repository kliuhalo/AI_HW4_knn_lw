import numpy as np
import matplotlib.pyplot as plt
import os, sys
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
import linear_regress_func 

class KNN_linear_regression():

    def __init__(self, x, y, k):
        self.x = x
        self.y = y
        self.test_x = None
        self.k = k

    def predict(self, test_x):
        self.test_x = test_x
        dists = self.compute_distances(test_x)
        test_labels = self.predict_labels(dists, k = self.k)
        return test_labels

    def compute_distances(self, test_x):

        self.test_x = test_x
        num_test = test_x.shape[0]
        num_train = self.x.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            for j in range(num_train):
                dists[i][j] = np.sum((test_x[i]-self.x[j])**2)**0.5
        return dists

    def predict_labels(self, dists):
        num_test = dists.shape[0]
        k = self.k
        y_pred = np.zeros(num_test)
        for i in range(num_test):
            index_min = np.argmin(np.asarray(dists[i]))
            to = index_min+int(k/2)+1
            if index_min < int(k/2):
                add_top = int(k/2)-index_min
                to+=add_top
                fromm = 0
            else:
                fromm = index_min - int(k/2)
            # 前後數 k/2 index
            knn_X = self.x[fromm: to]
            knn_Y = self.y[fromm: to]

            # b = linear_regress_func.estimate_coef(knn_X,knn_Y)
            # y_pred[i] = b[0] + b[1] * self.test_x[i]

            # b = linear_regress_func.least_square2(knn_X, knn_Y)
            # y_pred[i] = b[0] + b[1] * self.test_x[i]
            m, c = linear_regress_func.least_square(knn_X, knn_Y)
            y_pred[i] = m*self.test_x[i] + c
            
        return y_pred


def dataset1():
    data = np.load('data/data1.npz')
    X = data['X'] 
    y = data['y']
    y = y.tolist()
    X = X.tolist()

    plt.figure()
    plt.scatter(X, y)
    plt.show()

    sorted_index = sorted(range(len(X)), key=lambda x:X[x])
    newY = [y[i]for i in sorted_index]
    newX = [X[i] for i in sorted_index]
    plt.figure()
    plt.scatter(newX, newY)
    plt.show()


    newX = np.asarray(newX)
    newY = np.asarray(newY)

    knnLR = KNN_linear_regression(newX, newY, 5)

    x_test = np.linspace(newX[0],newX[-1],len(newX))[:,None]
    print("shape of x_test",np.shape(x_test))

    dists = knnLR.compute_distances(x_test)
    print("distance array", np.shape(dists))

    y_pred = knnLR.predict_labels(dists)

    

    print(np.shape(x_test), np.shape(np.asarray(y_pred)))
    plt.figure()
    plt.scatter(newX, newY)
    plt.plot(x_test,np.asarray(y_pred), c='r')
    plt.show()

    plt.figure()
    plt.plot(x_test,np.asarray(y_pred), c='r')
    plt.show()

from mpl_toolkits import mplot3d 

if __name__ =='__main__':
    data = np.load('data/data2.npz')
    X = data['X'] 
    y = data['y']
    print(type(X[:][0]), type(y[:]))

    fig = plt.figure()
    ax = fig.gca(projection='3d')
    newX1 = X[:,0]
    newX2 = X[:,1]
    
    print(newX1.shape, newX2.shape,y.shape)#newY.shape)
    ax.plot_trisurf(newX1, newX2, y)#newY)
    #plt.show()

    sorted_index = sorted(range(len(X)), key=lambda x:(X[x,0],X[x,1]))
    newY = [y[i]for i in sorted_index]
    newX1 = [newX1[i] for i in sorted_index]
    newX2 = [newX2[i] for i in sorted_index]


    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.plot_trisurf(newX1, newX2, newY)
    #plt.show()

    test_x = np.linspace((newX1[0],newX2[0]),(newX1[-1],newX2[-1]),1000)
    print(test_x[0], test_x[-1])
    print("Test x shape", test_x.shape)