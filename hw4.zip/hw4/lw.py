import numpy as np
import os
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

def weight_matrix(point, X, tau, m):
    
    w = np.mat(np.eye(m)) 
    tau = 0.5
    for i in range(m): 
        xi = X[i] 
        d = (-2 * tau * tau) 
        w[i, i] = np.exp(np.dot((xi-point), (xi-point).T)/d) 
    return w

def predict(newX, newY):
    m = newX.shape[0]
    X = np.vstack([newX, np.ones(m)]).T
    newY = newY[:, np.newaxis]

    # predict
    predicts = []
    x_test = np.linspace(newX[0],newX[-1],len(newX))[:,None]
    x_test = x_test.tolist()
    for i in range(len(x_test)):
        point = float(x_test[i][0])
        point_ = np.array([point, 1])
        tau = 1
        Wm = weight_matrix(point_, X, tau, m)

        # print(Wm.shape, newY.shape, X.shape)
        theta = np.linalg.pinv(X.T*(Wm * X))*(X.T*(Wm * newY)) 
        
        pred = np.dot(point_, theta)
        # print(pred)
        # print(pred.shape)
        predicts.append(pred)
    predicts = np.squeeze(np.asarray(predicts))

    plt.figure()
    plt.scatter(newX, newY)

    plt.plot(x_test, predicts, c = 'r')
    plt.show()
    return predicts

def dataset1():
    data = np.load('data/data1.npz')
    X = data['X'] 
    y = data['y']
    y = y.tolist()
    X = X.tolist()

    sorted_index = sorted(range(len(X)), key=lambda x:X[x])
    newY = [y[i]for i in sorted_index]
    newX = [X[i] for i in sorted_index]

    newX = np.asarray(newX)
    newY = np.asarray(newY)
    
    
    predicts = predict(newX, newY)


if __name__=="__main__":

    data = np.load('data/data2.npz')
    X = data['X'] 
    y = data['y']
    newX1 = X[:,0]
    newX2 = X[:,1]
    sorted_index = sorted(range(len(X)), key=lambda x:(X[x,0],X[x,1]))
    newY = [y[i]for i in sorted_index]
    newX1 = [newX1[i] for i in sorted_index]
    newX2 = [newX2[i] for i in sorted_index]
    test_x = np.linspace((newX1[0],newX2[0]),(newX1[-1],newX2[-1]),1000)
    
    
