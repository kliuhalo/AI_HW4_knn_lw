import numpy as np
import matplotlib.pyplot as plt
import os, sys
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
import linear_regress_func 

from mpl_toolkits import mplot3d 

def compute_distances_2(test_x):
    num_test = test_x.shape[0] * test_x.shape[1]
    
    pass

data = np.load('data/data2.npz')
data = np.load('data/data2.npz')
X = data['X'] 
y = data['y']

fig = plt.figure()
ax = fig.gca(projection='3d')
newX1 = X[:,0]
newX2 = X[:,1]
ax.plot_trisurf(newX1, newX2, y)
plt.show()

sorted_index = sorted(range(len(X)), key=lambda x:(X[x,0],X[x,1]))
newY = [y[i]for i in sorted_index]
newX1 = [newX1[i] for i in sorted_index]
newX2 = [newX2[i] for i in sorted_index]


fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot_trisurf(newX1, newX2, newY)
plt.show()

test_x = np.linspace((newX1[0],newX2[0]),(newX1[-1],newX2[-1]),1000)#[:,None]
print(newX1[0],newX1[-1])
print(newX2[0], newX2[-1])

print("Test x shape", test_x.shape)
print(min(test_x[:,0]))
print(max(test_x[:,1]))

#dists = compute_distances_2(x_test)
train_data = list(zip(newX1, newX2))
print("total training data",len(train_data))
newX1 = np.array(newX1)
newX2 = np.array(newX2)
num_test = test_x.shape[0]#newX1.shape[0] * newX2.shape[0]
num_train = len(train_data)
print(num_test, num_train)

# compute distance
dists = np.zeros((num_test, num_train))
for i in range(num_test):
    for j in range(num_train):
        dists[i][j]= np.sum((test_x[i]-train_data[j][0])**2+(test_x[i]-train_data[j][1])**2)**0.5
print(dists.shape)

# predict test_x
k = 5
y_pred = np.zeros(num_test)

for i in range(num_test):
    index_min = np.argmin(np.asarray(dists[i]))
    to = index_min + int(k/2)+1
    if index_min < int(k/2):
        add_top = int(k/2)-index_min
        to+=add_top
        fromm = 0
    else:
        fromm = index_min - int(k/2)

    # 前後數 k/2 index
    knn_X1 = newX1[fromm:to]
    knn_X2 = newX2[fromm:to]
    knn_Y = newY[fromm:to]
    train_data = np.array(list(zip(knn_X1, knn_X2)))
    knn_Y = np.array(knn_Y)
    print("train data", train_data)
    print("train y", knn_Y)

    # train_data = np.array([[2,2],[3,3],[4,4]])
    # knn_Y = np.array([6,8,10])

    # print("train data", train_data)
    # print("train y", knn_Y)
    
    m1, m2, c =linear_regress_func.least_square2(train_data, knn_Y)
    y_pred[i] = m1 * test_x[i][0] + m2 * test_x[i][1] + c
print("max of y pred",np.max(y_pred))
print("min of y pred",np.min(y_pred))
print(type(test_x[:,1].tolist()))
print("test_x[:,1]",type(test_x[:,1][0]))

fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot_trisurf(test_x[:,0].tolist(), test_x[:,1].tolist() , y_pred.tolist())
plt.show()

test_x = np.array([ [i,i]for i in range(num_test)])
print("test_x", test_x.shape)




# fig = plt.figure()
# ax = fig.gca(projection='3d')
#test_x = np.squeeze(test_x)
# print(np.squeeze(test_x[:,:,0]).shape, np.squeeze(test_x[:,:,1]).shape,np.asarray(y_pred).shape)
# for x,y,z in zip(np.squeeze(test_x[:,:,0]),np.squeeze(test_x[:,:,1]), np.asarray(y_pred)):
#     print(x,y,z)
# ax.plot_trisurf(np.squeeze(test_x[:,:,0]),np.squeeze(test_x[:,:,1]) ,np.asarray(y_pred),c='r')
# plt.show()

